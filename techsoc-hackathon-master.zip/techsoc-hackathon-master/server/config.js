process.env.PG_STUDENTS_HOST = 'hhnsc.postgres.database.azure.com'
process.env.PG_STUDENTS_USER = 'hhnsc'
process.env.PG_STUDENTS_PASSWORD = '!>7>^qqbN^T6' 
process.env.PG_STUDENTS_DATABASE = 'techsoc'
process.env.PG_STUDENTS_PORT = 5432
process.env.PG_STUDENTS_SSL = true
process.env.JWT_SECRET = '!>7>^qqbN^T6'