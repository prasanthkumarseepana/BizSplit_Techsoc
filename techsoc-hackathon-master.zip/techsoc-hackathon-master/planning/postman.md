{
"email_id" : "harihara.sn@gmail.com",
"name" : "HHN",
"mobile_numeber" : "6369719275",
"password" : "abc"

}

{
"username" : "harihara.sn@gmail.com"
"password" : "abc"
}

    {
    "budget_id" : "3ce6b7c0-2b8b-11ed-9d83-6045bdad15ba",
    "total_amount" : 2000
    }
